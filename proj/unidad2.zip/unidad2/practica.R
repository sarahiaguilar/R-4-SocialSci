# 2.1. Instanciando objetos con vectores
a <- TRUE
mi_variable <- c(FALSE, TRUE)
b <- 3 == 3

x <- "¡Hola, mundo!"
y <- c("2", "3", "dos", "tres")

s <- 42L
t <- c(2L, 3L, NA)

i <- 42
j <- c(sqrt(2) ^ 2, 1, Inf)

ages <- list(22, 23, 22, 21, 25)
list_of_lists <- list("arroz", 
                      "pasta", 
                      list("manzanas", "kiwis", "uvas"), 
                      c("leche", "huevo", "mantequilla", 3))
print(list_of_lists)


# 2.2. Conociendo a un objeto
is.logical(TRUE)
is.character("¡Hola, mundo!")
is.integer(42L)
is.double(2)
is.na(NA)
is.nan(NaN)
is.infinite(-Inf)

typeof(x)
length(y)

print(y[1])
print(y[1:4])
y[1] <- "dos"










