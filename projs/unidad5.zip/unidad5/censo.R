library(data.table)

censo_iter <- fread("./datos/iter_09_2020_csv/ITER_09CSV20.csv")
# View(head(censo_iter, 100))

censo_total_cdmx <- censo_iter[NOM_MUN == "Total de la entidad Ciudad de México", ]
censo_total_mun <- censo_iter[NOM_MUN != "Total de la entidad Ciudad de México" & NOM_LOC == "Total del Municipio", ]
censo_total_loc <- censo_iter[NOM_MUN != "Total de la entidad Ciudad de México" & NOM_LOC != "Total del Municipio", ]

censo_total_mun[, .(NOM_MUN, P15A17A, PEA)]