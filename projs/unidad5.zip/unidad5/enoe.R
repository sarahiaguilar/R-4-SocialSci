library(data.table)

sd <- fread("./datos/enoe_n_2022_trim1_csv/ENOEN_SDEMT122.csv")
enoe <- fread("./datos/enoe_n_2022_trim1_csv/ENOEN_COE1T122.csv")

View(enoe[1:50, ])

dt <- merge(x = enoe, 
            y = sd,
            by = c("cd_a", "ent", 
                   "con", "v_sel",
                   "tipo", "mes_cal",
                   "n_hog", "h_mud",
                   "n_ren"))

sd[sub_o == 1, .(total_pob = sum(fac_tri)), by = .(sub_o, sex)]
