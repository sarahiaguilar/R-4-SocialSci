library(data.table)

viv <- fread("./datos/enigh2020_ns_viviendas_csv/viviendas.csv")
hog <- fread("./datos/enigh2020_ns_hogares_csv/hogares.csv")

dt <- merge(x = viv,
            y = hog,
            by = "folioviv",
            all.y = TRUE)

View(hog[, .(total_hogares = .N), by = folioviv])
# Vivienda con mas hogares: 1601079606

View(hog[folioviv == 1601079606, ])
View(viv[folioviv == 1601079606, ])

View(dt[folioviv == 1601079606, ])

hog[, .(total_hogares = .N), by = num_bici]

View(hog[, .(num_bici)])