library(data.table)
library(foreign)

# 3.3. Creando un data table ----------------------------------------------
# Desde 0
x <- 1:200
y <- rnorm(200, mean=70, sd=10)
dt <- data.table(id=x, age=y) 

# A partir de un data frame
df <- data.frame(id=x, age=y) 
dt <- data.table(df)

# A partir de un archivo con formato tabular
dt <- fread("./datos/pob_censo_2020_inegi.csv", encoding = "UTF-8")
dt_link <- fread("https://raw.githubusercontent.com/sarahiaguilar/R-4-SocialSci/gh-pages/data/pob_censo_2020_inegi.csv")
dt_txt <- fread("./datos/pob_censo_2020_inegi.txt", header=FALSE, sep=";")
df_xlsx <- readxl::read_xlsx("./datos/pob_censo_2020_inegi.xlsx", sheet=1)
# df_spss <- read.spss("example.sav", to.data.frame=TRUE, use.value.labels=FALSE)
# df_stata <- read.dta("example.dta")

# Leer múltiples hojas de un Excel y pegarlas en un solo data frame
# df <- data.frame(x=NA, y=NA)
# for (i in 1:32) {
#  df_i <- readxl::read_xlsx("./datos/pob_censo_2020_inegi.xlsx", sheet=i)
#  df <- cbind(df, df_i)
# }


# 3.3. Conociendo a un data table -----------------------------------------
head(dt)
tail(dt)
head(dt, n=10)
colnames(dt)
dim(dt)
nrow(dt)
ncol(dt)
str(dt)
summary(dt)
View(dt)


# 3.4. Renombrando columnas de un data.table ------------------------------
setnames(dt, 
         old = c("hombres", "mujeres"), 
         new = c("pob_hombres", "pob mujeres"))

setnames(dt,
         old = colnames(dt), 
         new = gsub(" ", "_", colnames(dt)))


# 3.5. Utilizando i en un data table --------------------------------------
# Tomando el subconjunto de filas i
View(dt[41, ])
View(dt[41:50, ])
View(dt[entidad_federativa == "Estados Unidos Mexicanos" & edad == 40, ])
View(dt[entidad_federativa %in% c("Estados Unidos Mexicanos", "Ciudad de México", "México") & edad == 40, ])
dt_40 <- dt[entidad_federativa %in% c("Estados Unidos Mexicanos", "Ciudad de México", "México") & edad == 40, ]

# Ordenando las filas usando las columnas i
View(dt[order(pob_hombres), ])
View(dt[order(-pob_hombres), ])
View(dt[order(entidad_federativa, pob_hombres), ])


# 3.6. Utilizando j en un data table --------------------------------------
# Tomando el subconjunto de columnas j
View(dt[, 2])
View(dt[, 2:3])
View(dt[, c(1, 3:4)])
View(dt[, .(entidad_federativa)])
View(dt[, .(entidad_federativa, edad)])
unique(dt[, edad])

# Calculando las nuevas columnas j
dt[, indice := 1:nrow(dt)]
dt[, pob_total := pob_hombres + pob_mujeres]
dt[, pob_total := ifelse(test = pob_total < 0,
                         yes = -1*pob_total, 
                         no = pob_total)]


# 3.8. Utilizando k en un data table --------------------------------------
dt[entidad_federativa != "Estados Unidos Mexicanos", sum(pob_hombres)]

View(dt[, .(total_pob_hombres = sum(pob_hombres), total_pob_mujeres = sum(pob_mujeres)), by = .(entidad_federativa)])

View(dt[entidad_federativa %in% c("Mexico", "Ciudad de México"), .(total_pob_mujeres = sum(pob_mujeres)), by = edad])



# 3.9. Unión de data tables  ----------------------------------------------
dt_lic <- fread("./datos/lic_censo_2020_inegi.csv", encoding = "UTF-8")

dt_pob_ags <- dt[entidad_federativa == "Aguascalientes", .(edad, pob_mujeres)]
dt_lic_ags <- dt_lic[ent_fed == "Aguascalientes" & sexo == "Mujeres", .(edad, estudiaron_licenciatura)]

typeof(dt_pob_ags[, edad])
typeof(dt_lic_ags[, edad])

dt_pob_ags[, edad := ifelse(edad == "100 y más", yes = "101", no = edad)]
dt_pob_ags[, edad := as.integer(edad)]

typeof(dt_pob_ags[, edad])
typeof(dt_lic_ags[, edad])

dt_merge <- merge(x = dt_pob_ags,
                  y = dt_lic_ags,
                  by.x = "edad", 
                  by.y = "edad", 
                  all.x = TRUE)

dt_merge <- merge(x = dt_pob_ags,
                  y = dt_lic_ags,
                  by.x = "edad", 
                  by.y = "edad", 
                  all.y = TRUE)

dt_merge <- merge(x = dt_pob_ags,
                  y = dt_lic_ags,
                  by.x = "edad", 
                  by.y = "edad", 
                  all = TRUE)



# 3.10. Reorientación de data tables --------------------------------------

# De formato largo a ancho
dt_lic_short <- dcast(data = dt_lic,
                      formula = ent_fed+edad~sexo, 
                      value.var = "estudiaron_licenciatura")

dt_lic_short <- dcast(data = dt_lic,
                      formula = ent_fed~sexo, 
                      value.var = "estudiaron_licenciatura",
                      fun.aggregate = sum)

# De formato largo a ancho
dt_lic_long <- melt(data = dt_lic_short, 
                    id.vars = "ent_fed", 
                    variable.name = "sexo",
                    value.name = "estudiaron_lic")