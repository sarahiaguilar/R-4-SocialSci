library(data.table)
library(foreign)

# 3.3. Creando un data table ----------------------------------------------
# Desde 0
x <- 1:200
y <- rnorm(200, mean=70, sd=10)
dt <- data.table(id=x, age=y) 

# A partir de un data frame
df <- data.frame(id=x, age=y) 
dt <- data.table(df)

# A partir de un archivo con formato tabular
dt <- fread("./datos/pob_censo_2020_inegi.csv", encoding = "UTF-8")
dt_link <- fread("https://raw.githubusercontent.com/sarahiaguilar/R-4-SocialSci/gh-pages/data/pob_censo_2020_inegi.csv")
dt_txt <- fread("./datos/pob_censo_2020_inegi.txt", header=FALSE, sep=";")
df_xlsx <- readxl::read_xlsx("./datos/pob_censo_2020_inegi.xlsx", sheet=1)
# df_spss <- read.spss("example.sav", to.data.frame=TRUE, use.value.labels=FALSE)
# df_stata <- read.dta("example.dta")

# Leer múltiples hojas de un Excel y pegarlas en un solo data frame
# df <- data.frame(x=NA, y=NA)
# for (i in 1:32) {
#  df_i <- readxl::read_xlsx("./datos/pob_censo_2020_inegi.xlsx", sheet=i)
#  df <- cbind(df, df_i)
# }


# 3.3. Conociendo a un data table -----------------------------------------
head(dt)
tail(dt)
head(dt, n=10)
colnames(dt)
dim(dt)
nrow(dt)
ncol(dt)
str(dt)
summary(dt)
View(dt)


# 3.4. Renombrando columnas de un data.table ------------------------------
setnames(dt, 
         old = c("hombres", "mujeres"), 
         new = c("pob_hombres", "pob mujeres"))

setnames(dt,
         old = colnames(dt), 
         new = gsub(" ", "_", colnames(dt)))


# 3.5. Utilizando i en un data table --------------------------------------
# Tomando el subconjunto de filas i
View(dt[41, ])
View(dt[41:50, ])
View(dt[entidad_federativa == "Estados Unidos Mexicanos" & edad == 40, ])
View(dt[entidad_federativa %in% c("Estados Unidos Mexicanos", "Ciudad de México", "México") & edad == 40, ])
dt_40 <- dt[entidad_federativa %in% c("Estados Unidos Mexicanos", "Ciudad de México", "México") & edad == 40, ]

# Ordenando las filas usando las columnas i
View(dt[order(pob_hombres), ])
View(dt[order(-pob_hombres), ])
View(dt[order(entidad_federativa, pob_hombres), ])


# 3.6. Utilizando j en un data table --------------------------------------
# Tomando el subconjunto de columnas j
View(dt[, 2])
View(dt[, 2:3])
View(dt[, c(1, 3:4)])
View(dt[, .(entidad_federativa)])
View(dt[, .(entidad_federativa, edad)])
unique(dt[, edad])

# Calculando las nuevas columnas j
dt[, indice := 1:nrow(dt)]
dt[, pob_total := pob_hombres + pob_mujeres]
dt[, pob_total := ifelse(test = pob_total < 0,
                         yes = -1*pob_total, 
                         no = pob_total)]
