library(data.table)
library(ggplot2)

p_raw <- fread("./datos/Personas09.CSV")

# View(head(p))
# NO VIEW()

p_raw[, sexo_factor := factor(x = SEXO, levels = c(1, 3), labels = c("Hombre", "Mujer"))]
p <- p_raw[EDAD != 999 & !is.na(EDAD), ]
p <- p[, .(ID_PERSONA, FACTOR, sexo_factor, EDAD)]

ggplot(data = p) + 
  aes(x = EDAD, weight = FACTOR, fill = sexo_factor) + 
  geom_histogram(bin = 100, position = "identity", alpha = 0.5)

ggplot(data = p) + 
  aes(x = EDAD, weight = FACTOR, fill = sexo_factor) + 
  geom_histogram(bin = 100, position = "identity", alpha = 0.5) + 
  coord_flip()

p[, edad_quinquenal := cut(x = p[, EDAD],
                           breaks = seq(0, 110, by = 5),
                           include.lowest = TRUE,
                           right = FALSE)]

p_grouped <- p[, .(pob = sum(FACTOR)), by = .(sexo_factor, edad_quinquenal)]

ggplot(data = p_grouped) + 
  aes(x = edad_quinquenal, y = pob, fill = sexo_factor) + 
  geom_bar(stat = "Identity", position = "identity", alpha = 0.5) + 
  coord_flip()

p_grouped[, pob := ifelse(sexo_factor == "Hombre", yes = -pob, no = pob)]

ggplot(data = p_grouped) + 
  aes(x = edad_quinquenal, y = pob, fill = sexo_factor) + 
  geom_bar(stat = "Identity", position = "identity") + 
  coord_flip()

ggplot(data = p_grouped) + 
  aes(x = edad_quinquenal, y = pob, fill = sexo_factor) + 
  geom_bar(stat = "Identity", position = "identity") + 
  scale_y_continuous(limits = c(-400000, 400000),
                     breaks = seq(-400000, 400000, by = 100000),
                     labels = c(400, 300, 200, 100, 0, 100, 200, 300, 400)) + 
  coord_flip()

ggplot(data = p_grouped) + 
  aes(x = edad_quinquenal, y = pob, fill = sexo_factor) + 
  geom_bar(stat = "Identity", position = "identity") +
  scale_fill_manual(values = c("#a35994ff", "#009482ff")) + 
  scale_y_continuous(limits = c(-400000, 400000),
                     breaks = seq(-400000, 400000, by = 100000),
                     labels = c(400, 300, 200, 100, 0, 100, 200, 300, 400)) + 
  coord_flip() +
  labs(title = "Pirámide poblacional de la Ciudad de México", 
       subtitle = "Población total (en miles de personas) por edad quinquenal",
       caption = "Censo de Población y Vivienda 2020 del INEGI\nElaborado por el CEDUA de El Colegio de México") +
  theme_minimal() +
  theme(axis.title = element_blank(),
        legend.title = element_blank(),
        legend.position = "bottom",
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        plot.title = element_text(hjust = 0.5),
        plot.subtitle = element_text(hjust = 0.5))

p_grouped[, pob_label := ifelse(sexo_factor == "Hombre", 
                                yes = paste0(round(-pob/1000), "          "),
                                no = paste0("          ", round(pob/1000)))]

ggplot(data = p_grouped) + 
  aes(x = edad_quinquenal, y = pob, fill = sexo_factor, label = pob_label) + 
  geom_bar(stat = "Identity", position = "identity") +
  scale_fill_manual(values = c("#a35994ff", "#009482ff")) + 
  scale_y_continuous(limits = c(-400000, 400000),
                     breaks = seq(-400000, 400000, by = 100000),
                     labels = c(400, 300, 200, 100, 0, 100, 200, 300, 400)) +
  geom_text(size = 3) +
  coord_flip() +
  labs(title = "Pirámide poblacional de la Ciudad de México", 
       subtitle = "Población total (en miles de personas) por edad quinquenal",
       caption = "Censo de Población y Vivienda 2020 del INEGI\nElaborado por el CEDUA de El Colegio de México") +
  theme_minimal() +
  theme(axis.title = element_blank(),
        legend.title = element_blank(),
        legend.position = "bottom",
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        plot.title = element_text(hjust = 0.5),
        plot.subtitle = element_text(hjust = 0.5))

# [ y paréntesis


View(head(p, n = 100))
unique(p[, edad_quinquenal])







