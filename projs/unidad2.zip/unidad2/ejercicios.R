# Ejercicio #1 ------------------------------------------------------------

# Cree un vector que contenga la numeración consecutiva de 1 a 50.
# Suponga que estas son la edades recolectadas en un censo de población en el poblado Z.
edades_encuestados <- 1:50

# El factor de expansión de cada uno de los individuos censados en el poblado Z es de 3.5. 
# Cree un objeto que guarde el valor de este factor de expansión.
fac_exp <- 3.5

# Calcule la media de edad de la población.
# Primero, sumamos las edades de los encuestados. 
suma_edades_z <- sum(edades_encuestados*fac_exp)

# Después, calculamos el tamaño de la población.
n_z <- 50*fac_exp

# Media de edad de población
edad_media_z <- suma_edades_z/n_z

# Si tuviese que calcular únicamente la edad de las edades recolectadas, 
# lo podría hacer con la función mean().
edad_media_encuestados <- mean(edades_encuestados) 


# Ejercicio #2 ------------------------------------------------------------

# ¿Cuál será el valor de x después de ejecutar el siguiente código? 
# El valor de x será 2. 

# Explicación: 
# Instancia objeto x con valor 1
x <- 1 

if (x == 1) { # Condición que se evalúa: ¿x es igual a 1?
  # Código que se ejecuta si la condición es verdadera
  # En este caso, la condición sí es verdadera.
  x <- 2 # Sobreescribe objeto x con valor 2
  
  if (x == 1) { # Condición que se evalúa: ¿x es igual a 1?
    # Código que se ejecuta si la condición es verdadera
    # En este caso, como x ya tiene el valor de 2, la condición es falsa y no se ejecuta la siguiente instrucción. 
    x <- 3
  }
}

# Imprime valor de x
print(x)


# Utilice instrucciones if y else para evaluar si la media de pobalación en el ejercicio anterior es mayor o igual que 30. 
# En caso de que lo sea, imprima "La media de población es mayor o igual que 30.", y en caso contrario, imprima el mensaje acorde.
if (edad_media_z >= 30) { # Condición que se evalúa: ¿edad_media_z es mayor o igual a 1?
  # Código que se ejecuta si la condición es verdadera
  # En este caso, la condición sí es falsa. 
  print("La media de población es mayor o igual que 30.") # Imprime leyenda
} else {
  # Código que se ejecuta si la condición es falsa
  print("La media de población es menor que 30.") # Imprime leyenda
}


# Ejercicio #3 ------------------------------------------------------------

# ¿Qué imprimirá el siguiente ciclo for? 
# Cada elemento del vector + 1, es decir, 2, 3, 5, 6 y 7. 

# Explicación: 
# Instancia objeto con vector con cinco valores
mi_vector <- c(1, 2, 4, 5, 6)
for (i in mi_vector) { # Recorre todos los valores de mi_vector
  # En cada iteración, a i se le asigna momentáneamente el valor de mi_vector al que corresponde cada iteración
  print(i + 1) # Imprime valor momentaneo de i + 1
}


# Imagine que le reportan que ha habido un error en el censo de población de Z: 
# a todas las edades menor o igual a 30, les han sumado 1 año de edad. 
# Utilice instrucciones for, if y else (en caso de ser necesario) para corregir el vector de edades que ya había almacenado.
aux <- 0 # Instancia objecto auxiliar con valor 0
for (i in edades_encuestados) { # Recorre todos los valores de edades_encuestados
  aux <- aux + 1 # Sumamos 1 al objeto auxiliar en cada ciclo
  if (edades_encuestados[aux] <= 30) { # Condición que se evalúa: ¿el valor de la posición aux de edades_encuestados es menor o igual a 30?
    edades_encuestados[aux] <- i - 1 # Corrige error en el valor de la posición aux de edades_encuestados
  } 
}



# Ejercicio #4 ------------------------------------------------------------

# Cree un función que tome una muestra aleatoria de tamaño n del vector de edades corregidas del censo de población de Z 
# y calcule su media, dado un factor de expansión e.
# Bonus: Verifique que n sea menor al tamaño de la población total de Z.

edad_promedio_muestra <- function(edades_encuestados, e, size_muestra) {
  # Calcula el tamaño de la población multiplicando el tamaño del vector con edades de los encuestados 
  # y el factor de expansión
  n_z <- length(edades_encuestados)*e
  
  if (size_muestra > n_z) { # Condición que se evalúa: ¿El tamaño de muestra es mayor que el tamaño de la población?
    return("Tamaño de muestra igual o mayor a tamaño de la población.") # Regresa mensaje 
  } 
  
  # Toma muestra aleatoria de tamaño size_muestra
  muestra_edades <- sample(edades_encuestados, size = size_muestra)
  
  # Suma las edades de la muestra
  suma_edades_z <- sum(muestra_edades*e)
  
  # Calcula el tamaño de la población que representa esa muestra
  n_muestra <- size_muestra*e
  
  # Media de edad de la muestra
  edad_media_muestra <- suma_edades_z/n_muestra
  
  # Devuelve media de edad de la muestra
  return(edad_media_muestra)
}

# Llamada a la función
edad_promedio_muestra(edades_encuestados = 1:100,
                      e = 4.2,
                      size_muestra = 30)
