# 2.1. Instanciando objetos con vectores
a <- TRUE
mi_variable <- c(FALSE, TRUE)
b <- 3 == 3

x <- "¡Hola, mundo!"
y <- c("2", "3", "dos", "tres")

s <- 42L
t <- c(2L, 3L, NA)

i <- 42
j <- c(sqrt(2) ^ 2, 1, Inf)

ages <- list(22, 23, 22, 21, 25)
list_of_lists <- list("arroz", 
                      "pasta", 
                      list("manzanas", "kiwis", "uvas"), 
                      c("leche", "huevo", "mantequilla", 3))
print(list_of_lists)


# 2.2. Conociendo a un objeto
is.logical(TRUE)
is.character("¡Hola, mundo!")
is.integer(42L)
is.double(2)
is.na(NA)
is.nan(NaN)
is.infinite(-Inf)

typeof(x)
length(y)

print(y[1])
print(y[1:4])
y[2] <- "300"


# 2.3. Convirtiendo el tipo de un vector
x <- "TRUE"
x <- as.logical(x)

x <- "2345"
x <- as.numeric(x)


## 2.4. Operaciones con vectores
a <- 1
factor_exp <- 300
valor_real <- a * factor_exp

x <- c(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10)  
x*2
sqrt(x)

sum(x)
mean(x)
median(x)
min(x)
max(x)

x_sample <- sample(x, size=10)
mean(x_sample)
median(x_sample)


# 2.5. Condicionando
num <- -5
if (num < 0) {
  print("El número es negativo.")
  
  print("Lo volveré positivo.")
  num <- num * -1 # Convierte por -1 para invertir su signo
  
  print("Ahora el número es positivo.")
}

num <- 8
if (num < 0) {
  print("El número es negativo.")
  
  print("Lo volveré positivo.")
  num <- num * -1 # Convierte por -1 para invertir su signo
  
  print("Ahora el número es positivo.")
} else {
  print("Tu número siempre fue positivo.")
}


# 2.6. Iterando
mi_vector <- c(1, 2, 4, 5, 6, "siete", "ocho")
for (i in mi_vector) {
  print(i)
}

mi_vector <- c(1, 2, 4, 5, 6)
for (i in mi_vector) {
  print(i + 1)
}


# 2.7. Una primer función
invierte_signo <- function(x){
  y <- x * -1
  return(y)
}

invierte_signo(-1)
invierte_signo(2)