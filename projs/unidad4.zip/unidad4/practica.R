library(data.table)
library(ggplot2)

mw <- data.table(ggplot2::midwest)


# 5.3. Los básicos --------------------------------------------------------

ggplot()



# 5.4. Datos --------------------------------------------------------------

ggplot(data = mw)



# 5.5. Estética -----------------------------------------------------------

ggplot(data = mw) + 
  aes(x = percollege, y = percbelowpoverty, color = state)



# 5.6. Objetos geométricos ------------------------------------------------

ggplot(data = mw) + 
  aes(x = percollege, y = percbelowpoverty) +
  geom_point(color = "black", size = 1, alpha = 0.5) +
  geom_smooth(color = "#c03f42")

ggplot(data = mw) +
  aes(x = state) + 
  geom_bar(stat = "count")

mw[, above_5_percblack := ifelse(test = percblack >= 5, 
                                 yes = "Sí", 
                                 no = "No")]
ggplot(data = mw) +
  aes(x = state, fill = above_5_percblack) + 
  geom_bar(stat = "count")

ggplot(data = mw) +
  aes(x = poptotal) + 
  geom_histogram(bins = 20)

ggplot(data = mw) +
  aes(x = percpovertyknown, y = state) + 
  geom_boxplot()

mu <- mean(mw[, percpovertyknown])
ggplot(data = mw) +
  aes(x = percpovertyknown, y = state) + 
  geom_boxplot() +
  geom_vline(xintercept = mu, linetype = "dotted")



# 5.7. Escalas ------------------------------------------------------------

ggplot(data = mw) + 
  aes(x = percollege, y = percbelowpoverty, color = state) + 
  geom_point() +
  scale_x_continuous() +
  scale_y_continuous() + 
  scale_colour_discrete()

ggplot(data = mw) + 
  aes(x = percollege, y = percbelowpoverty) + 
  geom_point() +
  scale_x_reverse()