library(data.table)

# 4. En el script, cargue el conjunto de datos del archivo pob_censo_2020_inegi.txt 
# a R como data table.
# dt <- fread("./datos/pob_censo_2020_inegi.txt", header = FALSE, sep = ";")
dt <- fread("./datos/pob_censo_2020_inegi.csv")


# 5.1. Asigne nuevos nombres de columnas a cada variable.
colnames(dt)
head(dt)
setnames(dt, 
         old = colnames(dt), 
         new = c("ent", "edad", "pob_masc", "pob_fem"))


# 5.2. Verifique que haya el mismo número de observaciones por cada entidad federativa.
View(dt[, .N, by = ent])


# 5.3. Ubique las observaciones y variables que contienen NAs 
# y reempláce los NAs por un valor que considere pertinente.
summary(dt)
which(is.na(dt[, .(pob_fem)]))

# Opción #1.1
pob2 <- sum(dt[ent != "Estados Unidos Mexicanos" & edad == "2", pob_fem])
pob3 <- sum(dt[ent != "Estados Unidos Mexicanos" & edad == "3", pob_fem])
pob4 <- sum(dt[ent != "Estados Unidos Mexicanos" & edad == "4", pob_fem])

dt[ent == "Estados Unidos Mexicanos" & edad == 2, pob_fem := pob2]
dt[ent == "Estados Unidos Mexicanos" & edad == 3, pob_fem := pob3]
dt[ent == "Estados Unidos Mexicanos" & edad == 4, pob_fem := pob4]

# Opción 1.2
a_vector <- c(2, 3, 4)
b_vector <- c(pob2, pob3, pob4)
for (i in 1:3) {
  a <- a_vector[i] # Edad en donde sustituir
  b <- b_vector[i] # Nuevo valor de pob_fem
  dt[ent == "Estados Unidos Mexicanos" & edad == a, pob_fem := b]
}

# Opción #2
pobmean <- mean(pob2, pob3, pob4)
dt[, pob_fem := ifelse(is.na(pob_fem), yes = pobmean, no = pob_fem)]


# 5.4. Responda: ¿cuál es la entidad federativa cuya relación hombres-mujeres es 
# la más alta a nivel nacional? La relación hombres-mujeres refiere a cuántos hombres hay por cada mujer en la entidad federativa)

# Opción 1
dt_relhm <- dt[ent != "Estados Unidos Mexicanos", .(relhm = sum(pob_masc)/sum(pob_fem)), by = ent]
dt_relhm <- dt_relhm[order(relhm), ]

# Opción 2
pob.2 <- (dt[, .(total_pob_hombres = sum(pob_masc), total_pob_mujeres = sum(pob_fem)), by = .(ent)]) 
pob.2$relacion <- (pob.2$total_pob_hombres/pob.2$total_pob_mujeres) 
pob.2 <- pob.2[order(relacion), ]


# 5.5. Cree un nuevo data table con la población de mujeres entre 18 y 65 años 
# por región geográfica y guárdelo en un nuevo archivo csv dentro de la carpeta “datos” del proyecto.
dt[, edad := ifelse(edad == "100 y más", yes = 101, no = edad)]
dt[, edad := as.integer(edad)]

dt_fem_1865 <- dt[edad >= 18 & edad <= 65, .(ent, edad, pob_fem)]

unique(dt[, edad])