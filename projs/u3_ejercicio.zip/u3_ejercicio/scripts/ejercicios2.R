library(data.table)

# 7. En este segundo script, cargue los conjuntos de datos de los archivos
# pob_censo_2020_inegi.txt y lic_censo_2020_inegi.csv a R como data tables.
pob <- fread("./datos/pob_censo_2020_inegi.txt", header = FALSE, sep = ";")
lic <- fread("./datos/lic_censo_2020_inegi.csv")

setnames(pob, 
         old = colnames(pob), 
         new = c("ent", "edad", "pob_masc", "pob_fem"))

pob2 <- sum(pob[ent != "Estados Unidos Mexicanos" & edad == "2", pob_fem])
pob3 <- sum(pob[ent != "Estados Unidos Mexicanos" & edad == "3", pob_fem])
pob4 <- sum(pob[ent != "Estados Unidos Mexicanos" & edad == "4", pob_fem])

pob[ent == "Estados Unidos Mexicanos" & edad == 2, pob_fem := pob2]
pob[ent == "Estados Unidos Mexicanos" & edad == 3, pob_fem := pob3]
pob[ent == "Estados Unidos Mexicanos" & edad == 4, pob_fem := pob4]



# 8.1. Cree un nuevo data table con la población total que estudiaron una licenciatura (o equivalente) 
# por entidad federativa, edad y sexo, 
# en donde la entidad federativa y la edad tienen formato largo y el sexo tiene formato ancho.

lic_reoriented <- dcast(data = lic, formula = ent_fed+edad~sexo, value.var = "estudiaron_licenciatura")


# 8.2. Cree un nuevo data table con dos variables: 
# una que refiera al porcentaje que representa la población total de mujeres 
# que estudiaron una licenciatura (o equivalente) de la población total de mujeres por entidad federativa, 
# y otra que refiera al porcentaje que representa la población total de hombres 
# que estudiaron una licenciatura (o equivalente) de la población total de hombres por entidad federativa.

pmujlic <- lic[sexo == "Mujeres", .(lic_fem = sum(estudiaron_licenciatura)), by = ent_fed]
phomlic <- lic[sexo == "Hombres", .(lic_hom = sum(estudiaron_licenciatura)), by = ent_fed]

pmuj <- pob[, .(pob_fem = sum(pob_fem)), by = ent]
phom <- pob[, .(pob_masc = sum(pob_masc)), by = ent]

dt <- merge(x = pmujlic, 
            y = phomlic,
            by = "ent_fed",
            all = TRUE)

dt <- merge(x = dt, 
            y = pmuj, 
            by.x = c("ent_fed"),
            by.y = c("ent"),
            all = TRUE)

dt <- merge(x = dt, 
            y = phom, 
            by.x = "ent_fed",
            by.y = "ent",
            all = TRUE)

dt[, pct_lic_muj := lic_fem/pob_fem]
dt[, pct_lic_hom := lic_hom/pob_masc]

# Faltó consideración: el data table lic solo contiene edades de 3 a 24